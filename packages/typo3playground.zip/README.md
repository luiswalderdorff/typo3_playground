Sitepackage for the project "typo3playground"
==============================================================

Add some explanation here.
